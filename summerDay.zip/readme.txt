Thank you for choosing the Summer Day Theme.

Version History:

version 1.0.0 - Hello world!

--------------------------------------------------------------------------------
For support, 
visit http://pure-essence.net/2013/04/26/child-theme-for-oriental-summer-day


--------------------------------------------------------------------------------
 Licenses:
--------------------------------------------------------------------------------
Summer Day is a child theme of oriental
oriental is licensed under the GPL.

== Bundled Resources: Images ==

* images/*.*: http://www.gnu.org/licenses/gpl-2.0.html


== Fonts ==

Google web fonts are licensed under open source licenses
https://developers.google.com/webfonts/faq


--------------------------------------------------------------------------------
